#include <algorithm>
#include <ext/algorithm>
#include <iterator>
#include <numeric>
#include <vector>

//////// Class definition

class Half_range_mode {
public:
  template <class T> 
  static double mode( T begin, T end, double beta, int mode_reps=1, int sample_size=0 );
private:
  template <class T>
  static double compute_half_range_mode( T begin, T end, double beta );
};





//////// Functions definitions

//// mode()

template <class T>
double Half_range_mode::mode( T begin, T end, double beta, int mode_reps, int sample_size ) {

  using namespace std;

  typedef typename iterator_traits<T>::value_type T_value_type;

  vector< T_value_type > local_data;
  typename vector< T_value_type >::iterator local_data_it;
  vector<double> results;
  int i, N;
  
  N = (int) (end - begin);

  // Create a local copy of data require sorting
  
  if ( sample_size == 0 ) {
    cerr << "Using full data set, with no bootstrap averaging..." << endl;
    // Use original data only, so ignore value of mode_reps
    if ( is_sorted( begin, end ) ) {
      // Already sorted, so don't bother making a copy
      return compute_half_range_mode( begin, end, beta );
    }
    else {
      // Make a local copy, sort it, then use that
      cerr << "Making local copy of data and sorting..." << endl;
      local_data.reserve( N );
      local_data.insert( local_data.end(), begin, end );
      sort( local_data.begin(), local_data.end() );
      return compute_half_range_mode( local_data.begin(), local_data.end(), beta );
    }
  }

  // Using subsampled data, so make room
  local_data.reserve( sample_size );
  local_data.insert(local_data.end(), sample_size, 0);

  cerr << "Beginning " << mode_reps << " bootstrap rounds... (sample size " << sample_size << ")..." << endl;

  // Should seed externally, so that users calling the function can use their
  // own seed values if desired. Also, if the function is being called multiple
  // times, it's better not to reseed every time.

  // srand( time( NULL ) );
  
  for ( i = 0; i < mode_reps; i++ ) {
    for ( local_data_it = local_data.begin(); local_data_it < local_data.end(); local_data_it++ ) {
      // Resample with replacement
      *local_data_it = begin[ rand() % N ]; 
    }
    // Old without-replacement call:
    // random_sample( begin, end, local_data.begin(), local_data.end() );
    sort( local_data.begin(), local_data.end() );
    results.push_back( compute_half_range_mode( local_data.begin(), local_data.end(), beta ) );
  }

  // Note: accumulate() takes it return data type from the init argument (the 0 here)
  return ( (double) accumulate( results.begin(), results.end(), (double) 0 ) / (double) mode_reps );

}




//// compute_half_range_mode()

template <class T>
double Half_range_mode::compute_half_range_mode( T begin, T end, double beta ) {

  /*
    This function is really only intended to work with sorted arrays/vectors of
    values. The more general prototyping here is used because problems arose
    when trying to compile with vector<T>::iterator types.
    
    For now, we only accept sorted data. Eventually, we should probably make a
    local copy and sort it if this is necessary.
  */

  using namespace std;

  assert( is_sorted( begin, end ) );

  double w, w_prime;
  T last, new_begin, new_end;
  vector<int> counts, J;
  vector<double> w_range;
  int i, s, e;
  int N, N_prime, N_double_prime;
  double lo, hi;

  last = end - 1;
  N = end - begin;

  // How many elements are in the set? Terminate recursion appropriately...

  switch ( N ) {

  case 1:
    return *begin;

  case 2:
    return .5 * ( *begin + *last );

    // Main recursive code begins here

  default:
    
    w = beta * ( *last - *begin ); 

    // If all values are identical, return immediately...

    if ( w == 0 ) return *begin;

    // If we're at the end of the data, counts can only get worse, so there's no point in continuing...
    e = 0;
    for( s = 0; s < N && e < N; s++ ) {
      while ( e < N && begin[ e ] <= begin[ s ] + w ) { e++; }
      counts.push_back( e - s );
    }

    // Maximum count, and its multiplicity

    N_prime = *( max_element( counts.begin(), counts.end() ) );

    for ( i = 0; i < (int) counts.size(); i++ ) if ( counts[i] == N_prime ) J.push_back( i );
    
    // Do we have more than one maximal interval?

    if ( J.size() == 1 ) { 
      // No... the interval's unique.
      new_begin = begin + J[0];
      new_end = begin + J[0] + N_prime;
    }
    
    else {

      // Yes.. What's the smallest range?
      for ( i = 0; i < (int) J.size(); i++ ) w_range.push_back( begin[ J[i] + N_prime - 1 ] - begin[ J[i] ] );
      w_prime = *( min_element( w_range.begin(), w_range.end() ) );

      // Set new begin and end. We skip the more cumbersome V.min and V.max of the Bickel algorithm

      i = 0;
      while( w_range[ i ] > w_prime ) i++;
      new_begin = begin + J[i];
      for ( ; i < (int) J.size(); i++ ) if ( w_range[ i ] == w_prime ) new_end = begin + J[i] + N_prime; 
      
    }
    
    // Adjustments in rare cases where the interval hasn't shrunk. Trim one end,
    // the other, or both if lo == hi. Originally, this was inside the else
    // block above. With discrete data with a small number of levels, it is
    // possible, however for |J| = 1 AND N_double_prime = N, leading to an
    // infinite recursion.
    
    N_double_prime = new_end - new_begin;
    if (N_double_prime == N ) {
      lo = new_begin[1] - new_begin[0];
      hi = new_begin[ N - 1 ] - new_begin[ N - 2 ];
      if ( lo <= hi ) { new_end--; }
      if ( lo >= hi ) { new_begin++; }
    }

    // Clean up and then go in recursively

    counts.clear(); J.clear(); w_range.clear();

    return compute_half_range_mode( new_begin, new_end, beta ); 

  }
  
}
