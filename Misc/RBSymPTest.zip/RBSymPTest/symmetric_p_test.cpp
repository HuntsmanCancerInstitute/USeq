#include <fstream>
#include <iostream>
#include <iterator>
#include <vector>
#include "symmetric_p.hh"


int main( int argc, char* argv[] ) {

  // Fix up to run from the command line with proper arguments...

  using namespace std;

  // Load double data from the file name given in first argument

  ifstream input_file;
  input_file.open( argv[1] );

  istream_iterator<double> start (input_file);
  istream_iterator<double> end;

  vector<double> v, result;
  back_insert_iterator< vector<double> > v_it (v);

  copy( start, end, v_it );

  input_file.close();

  cerr << v.size() << " values read." << endl;

  // Compute

  srand( time( NULL ) );
  result = symmetric_null_p( v.begin(), v.end(), .5, atoi( argv[2] ), atoi( argv[3] ), 0 );
  copy( result.begin(), result.end(), ostream_iterator<double>( cout, "\n" ) );

}
