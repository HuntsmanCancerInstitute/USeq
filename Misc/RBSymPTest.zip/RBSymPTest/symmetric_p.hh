#include <algorithm>
#include <ext/algorithm>
#include <iostream>
#include <iterator>
#include <math.h>
#include <vector>

#include "half_range_mode.hh"
#include "ecdf.hh"

template <class T>
vector<double> symmetric_null_p( T source_begin, T source_end, double beta, int mode_reps, int mode_sample_size, int ecdf_sample_size = 0 ) {

  using namespace std;

  typedef typename iterator_traits<T>::value_type T_value_type;

  // Variable declarations
  vector< T_value_type > data, data_symm;
  typename vector< T_value_type >::iterator data_it, temp_it;
  double M;
  Ecdf< T_value_type > null_ecdf;
  int i, N;
  
  // Make a local version in vector format, for sorting and further processing.
  data.reserve( source_end - source_begin );
  data.insert( data.end(), source_begin, source_end );
  if ( !is_sorted( data.begin(), data.end() ) ) sort( data.begin(), data.end() );
  
  // Compute median (just one pass for the moment) and set an iterator just beyond it
  M = Half_range_mode::mode( data.begin(), data.end(), beta, mode_reps, mode_sample_size );
  data_it = upper_bound( data.begin(), data.end(), M );
  N = data_it - data.begin();
  cerr << "Mode estimate: " << M << endl;

  // Values for computing the ecdf.
  if ( ecdf_sample_size == 0 ) {
    // Use everything. Reflected values are added in reverse order so that
    // Ecdf::add() will not need to resort unnecessarily.
    data_symm.reserve( 2 * N );
    data_symm.insert( data_symm.end(), data.begin(), data_it );
    for ( temp_it = data_it; temp_it > data.begin();  ) {
      // Note that we don't actually retrieve *data_it
      temp_it--;
      data_symm.push_back( 2 * M - *temp_it );
    }
  }

  else {
    data_symm.reserve( ecdf_sample_size );
    for( i = 0; i < floor( (double) ecdf_sample_size / (double) 2 ); i++ ) {
      data_symm.push_back( data.begin()[ rand() % N ] );
      data_symm.push_back( 2 * M - data.begin()[ rand() % N ] );
    }
    if ( ecdf_sample_size % 2 == 1 ) data_symm.push_back( data.begin()[ rand() % N ] );
  }
  

  // Make ecdf
  null_ecdf.add( data_symm.begin(), data_symm.end() );

  return null_ecdf.F( source_begin, source_end );

}


